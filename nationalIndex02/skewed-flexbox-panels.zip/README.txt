A Pen created at CodePen.io. You can find this one at http://codepen.io/hexagoncircle/pen/yOwvQV.

 Experimenting with skew transforms applied to a series of flexbox panels. Switches the flex-direction to columns for smaller screen sizes. Click the toggle button to see panel transitions without background images.